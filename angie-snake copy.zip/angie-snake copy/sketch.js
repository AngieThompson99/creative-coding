var s;
var scl = 20; // nthis if for the scale oif the grid to keepo track of how big the snake is
var myAngle = 30;
var food;
var gui;
var backgroundColour = 220;
var foodred = 255;
var foodgreen = 0;
var foodblue = 100;
var snakeColour = 255;
var system;


function setup(){
    createCanvas(1000, 1000);
    background(backgroundColour);
    system = new ParticleSystem(createVector(width/2, 100));
	

    s = new Snake();
    frameRate(5);
    pickLocation();// make the food at the locations we picked
    //createVector(random(width), random(height));

    //gui
    sliderRange(0, 90, 1);
    gui = createGui('Snake slider customisation');
    gui.addGlobals('myAngle', 'snakeColour', 'backgroundColour', 'foodred', 'foodgreen', 'foodblue');
}
function pickLocation(){ // only pick alocation that is a spot on the grid
    var cols = floor(width/scl); // floor make sit a whole number
    var rows = floor(height/scl);
    food = createVector(floor(random(cols)), floor(random(rows)));
    food.mult(scl);// multply is by the scale to expand it back out
}

function draw(){
    background(backgroundColour);
    if (s.eat(food)){// SNAKE EATS FOOD  
        pickLocation(); // when the food is eaten, respawn the food in a new location
    }
    s.death(); // checks death before update
    s.update(); //updates the values
    s.show(); // show the updated snake

    system.addParticle();
    system.run(); // run theb array for the particles

    fill(foodred, foodgreen, foodblue); // COLOUR OF FOOD
    rect(food.x, food.y, scl, scl);// food is already assisned a random location, the size is the scl

}


function keyPressed(){ // s.dir is defined in snake.js
    if(keyCode === UP_ARROW){ // ^ if i press the up arrow i want the y axis number to get smaller so that it means it going up
        s.dir(0,-1); // dir = 0;
      
    }else if (keyCode === DOWN_ARROW ){ // if i press the down arrow
        //then i want the direction of the y axis to go down so the number of the y gets bigger
        // this mean if i press the down arrow then it will go down
        s.dir(0,1); // dir = 1;
        
    }else if (keyCode === RIGHT_ARROW ){ // right arrow the x axis gets longer and so it goes to the right --->
        s.dir(1, 0); // dir = 4;
    }else if (keyCode === LEFT_ARROW ){ // if i press the left arrow the the x axis gets smaller and is going to the left <----
        s.dir(-1, 0); // dir = 3;
}
}
var Particle = function(position) {
    this.acceleration = createVector(0, 0.03);
    this.velocity = createVector(random(-1,1), random(-1, 0));
    this.position = position.copy();
    this.lifespan = 4000.0;
  };
  
  Particle.prototype.run = function() {
    this.update();
    this.display();
  };
  
  // Method to update position
  Particle.prototype.update = function(){
    this.velocity.add(this.acceleration);
    this.position.add(this.velocity);
    this.lifespan -= 2;
  };
  
  // Method to display
  Particle.prototype.display = function() {
    stroke(255, this.lifespan);
    strokeWeight(0);
    fill(30, 144, 255, this.lifespan);
    ellipse(this.position.x, this.position.y, 3, 3);
  };
  
  // Is the particle still useful?
  Particle.prototype.isDead = function(){
    if (this.lifespan < 0) {
      return true;
    } else {
      return false;
    }
  };
  
  var ParticleSystem = function(position) {
    this.origin = position.copy();  // cop the original one
    this.particles = [];
  };
  
  ParticleSystem.prototype.addParticle = function() {
    this.particles.push(new Particle(this.origin)); //push new particles from the origin
  };
  
  ParticleSystem.prototype.run = function() {
    for (var i = this.particles.length-1; i >= 0; i--) {
      var p = this.particles[i];
      p.run();
      if (p.isDead()) {
        this.particles.splice(i, 1);
      }
    }
  };
